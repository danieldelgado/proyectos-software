package com.example;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.messaging.simp.config.StompBrokerRelayRegistration;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig extends AbstractWebSocketMessageBrokerConfigurer {

	@Override
	public void configureMessageBroker(MessageBrokerRegistry config) {
		
		StompBrokerRelayRegistration relay=config.enableStompBrokerRelay("/connect/", "/topic/");
		
        relay.setSystemLogin("login");
        relay.setSystemPasscode("passcode");
        
		config.enableSimpleBroker("/topic");
		config.setApplicationDestinationPrefixes("/app");
	}

	@Override
	public void registerStompEndpoints(StompEndpointRegistry registry) {
//		StompBrokerRelayRegistration relay=registry.
//        relay.setSystemLogin("login");
//        relay.setSystemPasscode("passcode");
		registry.addEndpoint("/connect").setAllowedOrigins("*").withSockJS();
	}

}