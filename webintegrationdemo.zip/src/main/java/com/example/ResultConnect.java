package com.example;
public class ResultConnect {

    private String content;

    public ResultConnect(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

}