package com.example;
public class ConductorConnect {

    private String name;

    public String getName() {
        return name;
    }

}