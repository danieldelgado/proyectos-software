package com.example;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;
import org.springframework.stereotype.Controller;

@Controller
public class MoveGoIntegrationController {

	private static List<UsuarioBean> listaUsuarioOnline = new ArrayList<>();
	private TaskScheduler scheduler = new ConcurrentTaskScheduler();

	@PostConstruct
	private void broadcastTimePeriodically() {
		scheduler.scheduleAtFixedRate(new Runnable() {
			@Override
			public void run() {
				updatelista(null);
			}
		}, 1000);
	}


	private void updatelista(UsuarioBean u ) {
		System.out.println(listaUsuarioOnline);
		System.out.println(u);
		if(u!=null){
			if(u.isConnect()){
				listaUsuarioOnline.add(u);
			}else{
				listaUsuarioOnline.remove(u);
			}			
		}		
	}
	
	@MessageMapping("/connect")
	@SendTo("/topic/resultconnect")
	public ResultConnect greeting(ConductorConnect message) throws Exception {
		System.out.println("1");
		Thread.sleep(3000);
		System.out.println("2");
		return new ResultConnect("Hello, " + message.getName() + "!");
	}

}