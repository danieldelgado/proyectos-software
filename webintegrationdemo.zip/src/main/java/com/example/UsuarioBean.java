package com.example;

public class UsuarioBean {

	private String idDispositivo;
	private String id;
	private String nombre;
	private String apellidos;
	private String tipoUsuario;
	private boolean connect;
	
	private VehiculoBean vehiculoBean;
	
	
	public String getIdDispositivo() {
		return idDispositivo;
	}
	public void setIdDispositivo(String idDispositivo) {
		this.idDispositivo = idDispositivo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getTipoUsuario() {
		return tipoUsuario;
	}
	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}
	public VehiculoBean getVehiculoBean() {
		return vehiculoBean;
	}
	public void setVehiculoBean(VehiculoBean vehiculoBean) {
		this.vehiculoBean = vehiculoBean;
	}
	public boolean isConnect() {
		return connect;
	}
	public void setConnect(boolean connect) {
		this.connect = connect;
	}
	
	
	
}
