package com.luxitec.movego.api;

import java.io.Serializable;

import com.luxitec.movego.util.entidades.EntityBean;

public class LocalizacionBean extends EntityBean implements Serializable{

	private String latitud;
	private String longitud;
	private String direccionActual;
	private boolean transcurso;
	private long   idUsuario;
	
	private double distancia;
	
	public String getLatitud() {
		return latitud;
	}
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}
	public String getLongitud() {
		return longitud;
	}
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}
	public String getDireccionActual() {
		return direccionActual;
	}
	public void setDireccionActual(String direccionActual) {
		this.direccionActual = direccionActual;
	}
	public boolean isTranscurso() {
		return transcurso;
	}
	public void setTranscurso(boolean transcurso) {
		this.transcurso = transcurso;
	}
	public long getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(long idUsuario) {
		this.idUsuario = idUsuario;
	}
	public double getDistancia() {
		return distancia;
	}
	public void setDistancia(double distancia) {
		this.distancia = distancia;
	}	
	
	
	
	
	
}
