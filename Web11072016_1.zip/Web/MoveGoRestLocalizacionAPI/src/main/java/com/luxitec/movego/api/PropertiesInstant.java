package com.luxitec.movego.api;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertiesInstant {
	
	private static Properties prop = null;

	public static PropertiesInstant init() {
		return new PropertiesInstant();
	}

	private PropertiesInstant() {
		try {
			prop = new Properties();
			prop.load(getClass().getClassLoader().getResourceAsStream("config.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static String getValue(String key){
		if(prop==null){
			init();
		}
		return prop.getProperty(key);
	}
	
}
