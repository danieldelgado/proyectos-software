package com.luxitec.movego.api;

public enum TipoImagen {
	BREVETE("BREVETE"), VEHICULO("VEHICULO"), CONDUCTOR("CONDUCTOR"), SOAT("SOAT");

	private String tipoImgen;

	TipoImagen(String tipoImgen) {
		this.tipoImgen = tipoImgen;
	}

	public String getTipoImgen() {
		return tipoImgen;
	}

}
