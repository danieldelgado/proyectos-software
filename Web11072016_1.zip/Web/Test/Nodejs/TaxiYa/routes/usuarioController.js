var express = require('express');
var router = express.Router();
var Usuario = require('../model/usuario');
var usuarioService = require("../service/usuarioService.js");

var fs = require('fs');
var path = require('path');

router.get('/principal', function(req, res, next) {
	res.render('usuario', {
		title : 'Express'
	});
});

router.route('/').get(function(req, res) {
	usuarioService.listar(null, function(err, listaUsuarios) {
		console.log(listaUsuarios);
		res.json(listaUsuarios);
	});
}).post(function(req, res) {
	var usuario = new Usuario(req.body);
	console.log(usuario);
	usuarioService.crear(usuario, function(error, usuarioNuevo) {
		if (error) {
			res.send(error);
		} else {
			res.send({
				message : 'Usuario nuevo'
			});
		}
	});
});

router.route('/:id').put(function(req, res) {
}).get(function(req, res) {
	usuarioService.get(req.params.id, function(error, usuario) {
		if (error) {
			res.send(error);
		} else {
			res.json(usuario);
		}
	});
})

router.route('/dni/:dni').get(function(req, res) {
	usuarioService.getByDNI(req.params.dni, function(error, usuario) {
		if (error) {
			res.send(error);
		} else {
			res.json(usuario);
		}
	});
})

router.route('/imagen/:fotocarp/:idusuario').get(
		function(req, res) {
			var idusuario = req.params.idusuario;
			var fotocarp = req.params.fotocarp;
			var rootPath = path.normalize(__dirname + '/..');
			var pathImg = "/uploads/fullsize/imagenes/" + fotocarp + "/"
					+ idusuario + "/05.jpg";
			var img = fs.readFileSync(rootPath + pathImg);
			res.writeHead(200, {
				'Content-Type' : 'image/jpg'
			});
			res.end(img, 'binary');
		});

router.route('/subirImagen/:fotocarp/:idusuario').post(
		function(req, res) {
			fs.readFile(req.files.image.path, function(err, data) {
				var idusuario = req.params.idusuario;
				var fotocarp = req.params.fotocarp;

				var rootPath = path.normalize(__dirname + '/..');
				var pathImg = "/uploads/fullsize/imagenes/" + fotocarp + "/"
						+ idusuario + "/05.jpg";
				var newPath = rootPath + pathImg;

				fs.writeFile(newPath, data, function(err) {
					res.redirect(pathImg);
				});

			});
		});

module.exports = router;
