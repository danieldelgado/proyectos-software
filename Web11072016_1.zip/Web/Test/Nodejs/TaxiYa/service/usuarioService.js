var usuarioDAO = require("../dao/usuarioDao.js");

exports.listar = function(filtro, callback) {
	usuarioDAO.listar(filtro, callback);
};

exports.crear = function(filtro, callback) {
	usuarioDAO.crear(filtro, callback);
};

exports.get = function(id, callback) {
	usuarioDAO.get(id, callback);
};

exports.getByDNI = function(dni, callback) {
	usuarioDAO.getByDNI(dni,  callback);
};
