var Usuario = require('../model/usuario');
exports.listar = function(filtro, callback) {
	Usuario.find(filtro,function(err, usuarios) {		
		console.log(usuarios);
		callback(err,usuarios);
	});
};

exports.get = function( id, callback ) {
	Usuario.findOne({
		_id : id
	}, function(err, usuario) {		
		if (callback) {
			callback(err,usuario);
		}		
	});
};

exports.getByDNI = function(dni, callback) {	
	Usuario.findOne({
		numeroDocumento : dni
	}, function(err, usuario) {
		if (callback) {
			callback(err,usuario);
		}
	});
};

exports.crear = function(model, callback) {
	var usuario = new Usuario(model);
	usuario.save(function(err) {
		if (err) {
			if (callback) {
				callback(err,null);
			}
		}
	});
	callback(null,usuario);
};

exports.update = function(id, model, callback) {
	Usuario.findOne({
		_id : id
	}, function(err, usuario) {
		if (err) {
			if (callback) {
				callback(err,null);
			}	
		}		
		uss = usuario;
		for (prop in model) {
			uss[prop] = model[prop];
		}	
		uss.save(function(err) {
			if (callback) {
				callback(err,null);
			}	
		});
		if (callback) {
			callback(null,uss);
		}	
	});
};

exports.remove = function(id, callback) {
	Usuario.remove({
		_id : id
	}, function(err, usuario) {
		if (callback) {
			callback(err,usuario);
		}
	});
};


/*var usuario = new Usuario({
nombre : 'Daniel',
apellidos : 'Delgado',
tipoDoc : '1',
numeroDocumento : '12341234'
});*/
