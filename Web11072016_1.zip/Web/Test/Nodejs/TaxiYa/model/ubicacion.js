var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var ubicacionSchema=new Schema({
	usuario : String,
	lat: String,
	log: String
});
//, default: Date.now
module.exports=mongoose.model('Ubicacion',ubicacionSchema);
