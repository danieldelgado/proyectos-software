var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var usuarioSchema = new Schema({
	nombre : String,
	apellidos : String,
	correo : String,
	password : String,
	tipoUsuario : Number,
	fechas : [ {
		fechaRegistro : {
			type : Date
		},
		fechaNacimiento : Date,
		fechaActualizar : {
			type : Date
		}
	} ],
	documentoIdentidad : [ {
		tipoDoc : String,
		numeroDocumento : String
	} ],
	vehiculo : [ {
		placaAuto : String,
		modeloAuto : String,
		licenciaConducir : String,
		fechaVencimientiLicencia : Date,
		soatVehicular : String,
	} ],
	telefonos : String,
	comentarios : [ {
		body : String,
		date : Date,
		usuario : mongoose.Schema.Types.ObjectId
	} ],
	valorizaciones : [ {
		numero : Number,
		date : Date,
		usuario : mongoose.Schema.Types.ObjectId
	} ],
	fotos : [ {
		fotoLicencia : mongoose.Schema.Types.ObjectId,
		fotoSoat : mongoose.Schema.Types.ObjectId,
		fotoUsuario : mongoose.Schema.Types.ObjectId,
		fotoVehiculo : mongoose.Schema.Types.ObjectId
	} ]
});
// , default: Date.now
module.exports = mongoose.model('Usuario', usuarioSchema);
