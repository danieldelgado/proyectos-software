var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var imagenSchema=new Schema({
    ruta:String
});

module.exports=mongoose.model('Imagen',imagenSchema);
