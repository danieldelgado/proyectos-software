package com.luxitec.movego.dao;

import java.util.List;

import com.luxitec.movego.domain.Localizacion;
import com.luxitec.movego.util.repository.IRepositoryDAO;

public interface LocalizacionDAO  extends IRepositoryDAO<Localizacion>{

	List<Localizacion> getLocalizacionCercanas(Localizacion o, int radioKm, Long[] idsUsuariosActivos);

	Localizacion getUltimaUbicacion(Long idUsuario);

	List<Localizacion> getListaConductores(Long[] idsConductoresActivos);

	List<Localizacion> getListaUsuarios(Long[] idsUusariosActivos);

	
		
}
