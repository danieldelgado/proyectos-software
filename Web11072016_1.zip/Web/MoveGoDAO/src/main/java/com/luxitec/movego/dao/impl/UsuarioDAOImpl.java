package com.luxitec.movego.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.luxitec.movego.dao.UsuarioDAO;
import com.luxitec.movego.domain.Usuario;
import com.luxitec.movego.tipos.TipoUsuario;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Repository("UsuarioDAO")
@SuppressWarnings("unchecked")
public class UsuarioDAOImpl extends RepositoryDAO<Usuario> implements UsuarioDAO {

	private static final Logger LOG = LoggerFactory.getLogger(UsuarioDAOImpl.class);

	@Override
	public Usuario getUsuarioForEmail(String email) throws MoveGoDAOException {

		final StringBuffer queryString = new StringBuffer("");
		queryString.append(" SELECT new Usuario( id,  nombre,  apellidoPaterno,  apellidoMaterno,  email) from Usuario u ");
		queryString.append(" where u.email = :email ");
		final Query query = this.em.createQuery(queryString.toString());
		query.setParameter("email", email);
		List<Usuario> lista = query.getResultList();
		if (!lista.isEmpty()) {
			return lista.get(0);
		}
		return null;
	}

	@Override
	public List<Usuario> getUsuarios(Usuario u) {
		final StringBuffer queryString = new StringBuffer("");
		queryString.append(" SELECT new Usuario( u.id,  u.nombre,  u.apellidoPaterno,  u.apellidoMaterno,  u.email,  u.online) from Usuario u ");
		establecerCondicion(queryString, " u.email like :email ", u.getEmail());
		establecerCondicion(queryString, " u.nombre like :nombre ", u.getNombre());
		establecerCondicion(queryString, " u.apellidoPaterno like :apellidoPaterno ", u.getApellidoPaterno());
		establecerCondicion(queryString, " u.apellidoMaterno like :apellidoMaterno ", u.getApellidoMaterno());
		establecerCondicion(queryString, " u.idVehiculoActual = :idVehiculoActual", u.getIdVehiculoActual());

		System.out.println(queryString.toString());
		LOG.info(queryString.toString());
		final Query query = this.em.createQuery(queryString.toString());

		establecerParam(query, "email", u.getEmail(),true,true);
		establecerParam(query, "nombre", u.getNombre(),true,true);
		establecerParam(query, "apellidoPaterno", u.getApellidoPaterno(),true,true);
		establecerParam(query, "apellidoMaterno", u.getApellidoMaterno(),true,true);
		establecerParam(query, "idVehiculoActual", u.getIdVehiculoActual());

		List<Usuario> lista = query.getResultList();
		System.out.println(lista);
		if (!lista.isEmpty()) {
			return lista;
		}
		return null;
	}

	@Override
	public List<Usuario> getListaUsariosTipo(TipoUsuario tipoUsuario) {
		final StringBuffer queryString = new StringBuffer("");
		queryString.append(" SELECT new Usuario( u.id,  u.nombre,  u.apellidoPaterno,  u.apellidoMaterno,  u.email,  u.online) from Usuario u ");
		queryString.append(" where u.tipoUsuario = :tipoUsuario ");
		final Query query = this.em.createQuery(queryString.toString());
		query.setParameter("tipoUsuario", tipoUsuario.getTipoUsuario());
		List<Usuario> lista = query.getResultList();
		return lista;
	}

}
