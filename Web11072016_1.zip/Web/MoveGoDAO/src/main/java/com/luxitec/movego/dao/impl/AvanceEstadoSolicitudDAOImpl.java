package com.luxitec.movego.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.AvanceEstadoSolicitudDAO;
import com.luxitec.movego.domain.AvanceEstadoSolicitud;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.repository.RepositoryDAO;

@SuppressWarnings("unchecked")
@Service("AvanceEstadoSolicitudDAO")
public class AvanceEstadoSolicitudDAOImpl extends RepositoryDAO<AvanceEstadoSolicitud> implements AvanceEstadoSolicitudDAO {

	@Override
	public List<AvanceEstadoSolicitud> getListaAvanceEstadoSolicitud(Long idSolicitud) {

		if (SimpleValidador.isNotNull(idSolicitud)) {
			final StringBuffer queryString = new StringBuffer("");
			queryString.append(" SELECT av from AvanceEstadoSolicitud av ");
			queryString.append(" where ");
			queryString.append(" av.solicitud.id like :solicitud ");
			final Query query = this.em.createQuery(queryString.toString());
			query.setParameter("solicitud",idSolicitud);
			List<AvanceEstadoSolicitud> lista = query.getResultList();
			if (!lista.isEmpty()) {
				return lista;
			}
		}
		return null;
	}

}
