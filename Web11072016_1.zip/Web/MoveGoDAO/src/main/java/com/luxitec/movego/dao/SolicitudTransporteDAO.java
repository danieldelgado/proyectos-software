package com.luxitec.movego.dao;

import java.util.List;

import com.luxitec.movego.domain.SolicitudTransporte;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.repository.IRepositoryDAO;

public interface SolicitudTransporteDAO extends IRepositoryDAO<SolicitudTransporte> {

	SolicitudTransporte getUltimaSolicitudTransporteBeanForUsuarioSolicitante(Long idUsuarioSolicitante) throws MoveGoDAOException;

	List<SolicitudTransporte> getSolicitudesTransportePorUsuarioSolicitante(Long idUsuarioSolicitante) throws MoveGoDAOException;

	
	
}
