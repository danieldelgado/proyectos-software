package com.luxitec.movego.dao.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.luxitec.movego.dao.SolicitudTransporteDAO;
import com.luxitec.movego.domain.SolicitudTransporte;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.repository.RepositoryDAO;

@Service("SolicitudTransporteDAO")
public class SolicitudTransporteDAOImpl extends RepositoryDAO<SolicitudTransporte> implements SolicitudTransporteDAO{

	@Override
	public SolicitudTransporte getUltimaSolicitudTransporteBeanForUsuarioSolicitante(Long idUsuarioSolicitante) throws MoveGoDAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SolicitudTransporte> getSolicitudesTransportePorUsuarioSolicitante(Long idUsuarioSolicitante) throws MoveGoDAOException {
		// TODO Auto-generated method stub
		return null;
	}

	
}
