package com.luxitec.movego.util.excepciones;

public class MoveGoServiceException extends MoveGoDAOException {
	private static final long serialVersionUID = 1L;
	private int codigoError;
	private String errorMessage;


	public MoveGoServiceException(int codigoError,String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
		this.codigoError = codigoError;
	}

	public MoveGoServiceException(int codigoError) {
		super(codigoError);
		this.codigoError = codigoError;
	}

	public int getCodigoError() {
		return codigoError;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	
	public MoveGoServiceException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}

	public MoveGoServiceException() {
		super();
	}
}
