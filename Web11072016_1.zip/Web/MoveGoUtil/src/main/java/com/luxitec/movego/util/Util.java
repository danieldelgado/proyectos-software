package com.luxitec.movego.util;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;

public class Util {

	private static Gson GSON = null;

	private static void init() {
		GsonBuilder builder = new GsonBuilder();
		builder.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {
			public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
				return new Date(json.getAsJsonPrimitive().getAsLong());
			}
		});

		GSON = builder.create();
	}

	public static String getJson(Object o) {
		if (GSON == null) {
			init();
		}
		return GSON.toJson(o);
	}

	public static Object getObject(String json, Class c) {
		if (GSON == null) {
			init();
		}
		return GSON.fromJson(json, c);
	}

	public static HttpResponse post(final String url, final String json) throws ClientProtocolException, IOException {
		HttpPost request = new HttpPost(url);
		StringEntity entity = new StringEntity(json);
		entity.setContentType("application/json;charset=UTF-8");
		entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json;charset=UTF-8"));
		request.addHeader("Authorization", "Basic ");
		request.setEntity(entity);
		HttpResponse response = null;
		HttpClient httpclient = HttpClientBuilder.create().build();
		response = httpclient.execute(request);
		return response;
	}
	
	public static HttpResponse put(final String url, final String json) throws ClientProtocolException, IOException {
		HttpPut request = new HttpPut(url);
		StringEntity entity = new StringEntity(json);
		entity.setContentType("application/json;charset=UTF-8");
		entity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json;charset=UTF-8"));
		request.addHeader("Authorization", "Basic ");
		request.setEntity(entity);
		HttpResponse response = null;
		HttpClient httpclient = HttpClientBuilder.create().build();
		response = httpclient.execute(request);
		return response;
	}


	public static HttpResponse post(final String url, Map<String, String> params) throws ClientProtocolException, IOException {
		HttpPost request = new HttpPost(url);
		List<NameValuePair> p = new ArrayList<NameValuePair>();
		for(Map.Entry<String,String> entry : params.entrySet()){			
			p.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));			
		}
		request.setEntity(new UrlEncodedFormEntity(p, "UTF-8"));		
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpResponse response  = httpclient.execute(request);
		return response;
	}

	public static HttpResponse put(final String url, Map<String, String> params) throws ClientProtocolException, IOException {
		HttpPut request = new HttpPut(url);
		List<NameValuePair> p = new ArrayList<NameValuePair>();
		for(Map.Entry<String,String> entry : params.entrySet()){			
			p.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));			
		}
		request.setEntity(new UrlEncodedFormEntity(p, "UTF-8"));		
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpResponse response  = httpclient.execute(request);
		return response;
	}


	public static HttpResponse get(String url, Map<String, String> params) throws ClientProtocolException, IOException {
		if(!SimpleValidador.isNull(params)){
			url = url + "?" + queryStrings(params);
		}
		HttpGet request = new HttpGet(url);
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpResponse response = httpclient.execute(request);
		return response;
	}

	public static HttpResponse get(String url, Object obj) throws ClientProtocolException, IOException, Exception {
		if(!SimpleValidador.isNull(obj)){
			url = url + "?" + queryString(introspect(null, obj));
		}
		HttpGet request = new HttpGet(url);
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpResponse response = httpclient.execute(request);
		return response;
	}

	public static String getEntry(final HttpResponse httpResponse) throws IOException {
		BufferedReader rd = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));
		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		return result.toString();
	}

	public static Map<String, Object> introspect(String name, Object obj) throws Exception {
		Map<String, Object> result = new HashMap<String, Object>();
		BeanInfo info = Introspector.getBeanInfo(obj.getClass());
		for (PropertyDescriptor pd : info.getPropertyDescriptors()) {
			Method reader = pd.getReadMethod();
			if (reader != null) {
				if ("class".equals(pd.getName())) {
					continue;
				}
				if (reader.invoke(obj) == null) {
					continue;
				}
				if (null == name) {
					result.put(pd.getName(), reader.invoke(obj));
				} else {
					result.put(name + "." + pd.getName(), reader.invoke(obj));
				}
			}
		}
		return result;
	}

	public static String convert(Object[] o) {
		StringBuilder sb = new StringBuilder();
		for (Object st : o) {
			sb.append(st).append(',');
		}
		if (o.length != 0)
			sb.deleteCharAt(sb.length() - 1);
		return sb.toString();
	}

	public static Object[] reconvert(String o) {
		Object[] a = o.split(",");
		return a;
	}

	@SuppressWarnings("rawtypes")
	public static String queryString(Map<String, Object> values) {
		StringBuilder sbuf = new StringBuilder();
		String separator = "";

		for (Map.Entry<String, Object> entry : values.entrySet()) {
			Object entryValue = entry.getValue();
			if (entryValue instanceof Object[]) {
				for (Object value : (Object[]) entryValue) {
					appendParam(sbuf, separator, entry.getKey(), value);
					separator = "&";
				}
			} else if (entryValue instanceof Iterable) {
				for (Object multiValue : (Iterable) entryValue) {
					appendParam(sbuf, separator, entry.getKey(), multiValue);
					separator = "&";
				}
			} else {
				appendParam(sbuf, separator, entry.getKey(), entryValue);
				separator = "&";
			}
		}

		return sbuf.toString();
	}

	public static String queryStrings(Map<String, String> values) {
		StringBuilder sbuf = new StringBuilder();
		String separator = "";

		for (Map.Entry<String, String> entry : values.entrySet()) {
			Object entryValue = entry.getValue();
			if (entryValue instanceof Object[]) {
				for (Object value : (Object[]) entryValue) {
					appendParam(sbuf, separator, entry.getKey(), value);
					separator = "&";
				}
			} else if (entryValue instanceof Iterable) {
				for (Object multiValue : (Iterable) entryValue) {
					appendParam(sbuf, separator, entry.getKey(), multiValue);
					separator = "&";
				}
			} else {
				appendParam(sbuf, separator, entry.getKey(), entryValue);
				separator = "&";
			}
		}

		return sbuf.toString();
	}

	private static void appendParam(StringBuilder sbuf, String separator, String entryKey, Object value) {
		String sValue = value == null ? "" : String.valueOf(value);
		sbuf.append(separator);
		sbuf.append(urlEncode(entryKey));
		sbuf.append('=');
		// sbuf.append(urlEncode(Util.getJson(sValue)));
		sbuf.append(urlEncode((sValue)));
		// sbuf.append((sValue));
	}

	static String urlEncode(String value) {
		try {
			return URLEncoder.encode(value, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			return value;
		}
	}

	public static String mapToString(Map<String, String> map) {
		StringBuilder stringBuilder = new StringBuilder();

		for (String key : map.keySet()) {
			if (stringBuilder.length() > 0) {
				stringBuilder.append("&");
			}
			String value = map.get(key);
			try {
				stringBuilder.append((key != null ? URLEncoder.encode(key, "UTF-8") : ""));
				stringBuilder.append("=");
				stringBuilder.append(value != null ? URLEncoder.encode(value, "UTF-8") : "");
			} catch (UnsupportedEncodingException e) {
				throw new RuntimeException("This method requires UTF-8 encoding support", e);
			}
		}

		return stringBuilder.toString();
	}

	public static Map<String, String> stringToMaps(String input) {
		if (GSON == null) {
			init();
		}
		Type type = new TypeToken<Map<String, String>>() {
		}.getType();
		Map<String, String> myMap = GSON.fromJson(input, type);
		return myMap;
	}

	public static Map<String, Object> stringToMap(String input) {
		if (GSON == null) {
			init();
		}
		Type type = new TypeToken<Map<String, String>>() {
		}.getType();
		Map<String, Object> myMap = GSON.fromJson(input, type);
		return myMap;
	}

}
