package com.luxitec.movego.util.service;

import java.util.List;

import com.luxitec.movego.util.entidades.EntityBean;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

public interface IService<T extends EntityBean> {
	
	void guardar(T o) throws MoveGoServiceException;
	T get(Long id)  throws MoveGoServiceException;
	void habilitar(T obj, boolean activo) throws MoveGoServiceException;
	List<T> todo() throws MoveGoServiceException;
	
}
