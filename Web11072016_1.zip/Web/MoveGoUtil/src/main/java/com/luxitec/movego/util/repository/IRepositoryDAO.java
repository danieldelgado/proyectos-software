package com.luxitec.movego.util.repository;

import java.util.List;

import com.luxitec.movego.util.entidades.EntityDAO;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;

public interface IRepositoryDAO<T extends EntityDAO> {
		
	void guardar(T o) throws MoveGoDAOException;
	T get(Long id)  throws MoveGoDAOException;
	void habilitar(T obj, boolean activo) throws MoveGoDAOException;
	List<T> todo() throws MoveGoDAOException;

}
