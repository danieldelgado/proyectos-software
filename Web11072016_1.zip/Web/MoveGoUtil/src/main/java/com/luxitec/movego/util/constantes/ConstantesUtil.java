package com.luxitec.movego.util.constantes;

public class ConstantesUtil {

	public static final int TRANSACCION_OK = 1;
	public static final int TRANSACCION_NO_OK = 0;

	public static class Errors {

		public static final String ERROR_CONEXION_BASE_DATOS = "movego.error.conexion.db";
		public static final String MENSAJE_VALIDADCION_INCORRECTA = "movego.error.validacion";
		public static final String MENSAJE_EMAIL_INCORRECTO = "movego.error.email.error";
		
		
		public static final int TRANSFORMAR_ERROR = 16700;
		public static final int TRANSFORMAR_ERROR_METODO_NO_ENCONTRADO = 16701;
		public static final int TRANSFORMAR_ERROR_SECURITY_ERROR = 16702;
		public static final int TRANSFORMAR_ERROR_ILLEGAL_ACCESS = 16703;
		public static final int TRANSFORMAR_ERROR_ILLEGAL_ARGUMENT = 16704;
		public static final int TRANSFORMAR_ERROR_IVOCATION_TARGE = 16705;
				

		public static final int ERROR_ENTIDAD_GUARDAR = 16800;
		public static final int ERROR_ENTIDAD_VALIDAR = 16801;
		public static final int ERROR_ENTIDAD_NO_ENCONTRADA = 16802;
		
		
	}

}
