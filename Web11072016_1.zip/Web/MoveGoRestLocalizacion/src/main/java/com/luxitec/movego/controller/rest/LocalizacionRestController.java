package com.luxitec.movego.controller.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.luxitec.movego.bean.LocalizacionBean;
import com.luxitec.movego.service.LocalizacionService;
import com.luxitec.movego.util.Util;
import com.luxitec.movego.util.excepciones.MoveGoControllerException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@RestController
@RequestMapping("/localizacion")
public class LocalizacionRestController extends com.luxitec.movego.util.controller.RestController {

	private static final Logger LOG = LoggerFactory.getLogger(LocalizacionRestController.class);

	@Autowired
	private LocalizacionService localizacionService;

	@RequestMapping(value = "/", method = RequestMethod.POST)
	@ResponseBody
	public LocalizacionBean registrarLocalizacion(@RequestBody LocalizacionBean localizacionBean) throws MoveGoControllerException {
		LOG.info("registrarLocalizacion");
		try {

			localizacionService.guardar(localizacionBean);
			return localizacionBean;
		} catch (MoveGoServiceException e) {
			e.printStackTrace();
		}
		return localizacionBean;
	}

	@RequestMapping(value = "/radio/{radioKm}", method = RequestMethod.GET)
	@ResponseBody
	public List<LocalizacionBean> getLocalizacionCercanas(@PathVariable("radioKm") int radioKm, 
			@RequestParam(value = "idsUsuariosActivos", required = true) String idsUsuariosActivos,
			@RequestParam(value = "idusuario", required = true) String idusuario, 
			@RequestParam(value = "longitud", required = true) String longitud, 
			@RequestParam(value = "latitud", required = true) String latitud
			)
			throws MoveGoControllerException {

		try {
			LocalizacionBean origen = new LocalizacionBean();
			origen.setIdUsuario(Long.valueOf(idusuario));
			origen.setLongitud(longitud);
			origen.setLatitud(latitud);

			Object[] lids = Util.reconvert(idsUsuariosActivos.replace("\"", ""));
			Long[] ids = null;
			if (lids != null && lids.length > 0) {
				ids = new Long[lids.length];
				for (int i = 0; i < lids.length; i++) {
					Object object = lids[i];
					ids[i] = new Long(object.toString());
				}
			}

			List<LocalizacionBean> rls = localizacionService.getLocalizacionCercanas(origen, radioKm, ids);
			return rls;
		} catch (MoveGoServiceException e) {
			e.printStackTrace();
		}

		return new ArrayList<>();
	}

	@RequestMapping(value = "/estimarEntrePuntos", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> estimarEntrePuntos(
			@RequestParam(value = "origenidusuario", required = true) String origenidusuario, 
			@RequestParam(value = "origenlongitud", required = true) String origenlongitud, 
			@RequestParam(value = "origenlatitud", required = true) String origenlatitud,
			@RequestParam(value = "destinoidusuario", required = true) String destinoidusuario, 
			@RequestParam(value = "destinolongitud", required = true) String destinolongitud, 
			@RequestParam(value = "destinolatitud", required = true) String destinolatitud) throws MoveGoControllerException {
		LOG.info("estimarEntrePuntos");

		try {
			LocalizacionBean o = new LocalizacionBean();
			o.setIdUsuario(Long.valueOf(origenidusuario));
			o.setLongitud(origenlongitud);
			o.setLatitud(origenlatitud);
			
			LocalizacionBean d = new LocalizacionBean();
			d.setIdUsuario(Long.valueOf(destinoidusuario));
			d.setLongitud(destinolongitud);
			d.setLatitud(destinolatitud);
						
			Map<String, Object> rls = localizacionService.estimarEntrePuntos(o, d);

			return rls;
		} catch (MoveGoServiceException e) {
			e.printStackTrace();
		}

		return null;
	}

	@RequestMapping(value = "/ultimaUbicacion/{idUsuario}", method = RequestMethod.GET)
	@ResponseBody
	public LocalizacionBean getUltimaUbicacion(@PathVariable("idUsuario")  Long idUsuario) throws MoveGoControllerException {
		LOG.info("getUltimaUbicacion");

		try {
			System.out.println(idUsuario);
			LocalizacionBean r = localizacionService.getUltimaUbicacion(idUsuario);

			return r;
		} catch (MoveGoServiceException e) {
			e.printStackTrace();
		}

		return null;
	}

	@RequestMapping(value = "/conductores", method = RequestMethod.GET)
	@ResponseBody
	public List<LocalizacionBean> getListaConductores(@RequestParam(value = "idsConductoresActivos", required = true) String idsConductoresActivos) throws MoveGoControllerException {
		LOG.info("estimarEntrePuntos");

		try {
			
			Object[] lids = Util.reconvert(idsConductoresActivos.replace("\"", ""));
			Long[] ids = null;
			if (lids != null && lids.length > 0) {
				ids = new Long[lids.length];
				for (int i = 0; i < lids.length; i++) {
					Object object = lids[i];
					ids[i] = new Long(object.toString());
				}
			}
			
			List<LocalizacionBean> rls = localizacionService.getListaConductores(ids);

			return rls;
		} catch (MoveGoServiceException e) {
			e.printStackTrace();
		}

		return null;
	}

	@RequestMapping(value = "/usuarios", method = RequestMethod.GET)
	@ResponseBody
	public List<LocalizacionBean> getListaUsuarios(@RequestParam(value = "idsUsariosActivos", required = true) String  idsUsariosActivos) throws MoveGoControllerException {
		LOG.info("estimarEntrePuntos");

		try {

			Object[] lids = Util.reconvert(idsUsariosActivos.replace("\"", ""));
			Long[] ids = null;
			if (lids != null && lids.length > 0) {
				ids = new Long[lids.length];
				for (int i = 0; i < lids.length; i++) {
					Object object = lids[i];
					ids[i] = new Long(object.toString());
				}
			}
			
			List<LocalizacionBean> rls = localizacionService.getListaUsuarios(ids);

			return rls;
		} catch (MoveGoServiceException e) {
			e.printStackTrace();
		}

		return null;
	}

}