package com.luxitec.movego.integrador.service;

import com.luxitec.movego.integrador.bean.Localizacion;
import com.luxitec.movego.integrador.bean.Usuario;
import com.luxitec.movego.integrador.controller.MovegoResult;

public interface IntegradorService {

	MovegoResult registrarLocalizacion(Usuario usuario, Localizacion localizacion);

	Usuario login(Usuario u);

}
