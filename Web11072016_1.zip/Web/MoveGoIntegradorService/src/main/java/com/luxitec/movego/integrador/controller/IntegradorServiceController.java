package com.luxitec.movego.integrador.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.luxitec.movego.integrador.bean.Usuario;
import com.luxitec.movego.integrador.service.IntegradorService;

@CrossOrigin(maxAge = 3600)
@RestController
@RequestMapping("/service")
public class IntegradorServiceController {

	@Autowired
	private IntegradorService integradorService;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String exite() {
		System.out.println("hola");
		return "Hola";
	}

	
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Usuario login(@RequestParam(name="login") String login,@RequestParam(name="pass") String pass ) {
		System.out.println("login");
		Usuario u = new Usuario();
		u.setLogin(login);
		u.setPass(pass);
		System.out.println("login:"+u.getLogin());
		System.out.println("login:"+u.getPass());
		
		u = integradorService.login(u);
				
		return u;
	}
	
	@MessageMapping("/movego_ws")
	@SendTo("/topic/resultconnect")
	public MovegoResult resultconnect(MovegoMessage message) throws Exception {
		MovegoResult r = null;
		String c = message.getCommand();
		System.out.println("resultconnect");
		System.out.println(c);
		System.out.println(message.getMensaje());
		System.out.println(message.getUsuario());
		System.out.println(message.getLocalizacion());
		if (c != null) {
			switch (c) {
			case MovegoMessage.COMMAND_LOCALIZACION:
				System.out.println("COMMAND_LOCALIZACION");
				r = integradorService.registrarLocalizacion(message.getUsuario(),message.getLocalizacion());
				break;
			case MovegoMessage.COMMAND_SOLICITUD:
				System.out.println("COMMAND_SOLICITUD");

				break;
			case MovegoMessage.COMMAND_CONFIRMAR_SOLICITUD:
				System.out.println("COMMAND_CONFIRMAR_SOLICITUD");

				break;

			}
		}

		return r;
	}

}