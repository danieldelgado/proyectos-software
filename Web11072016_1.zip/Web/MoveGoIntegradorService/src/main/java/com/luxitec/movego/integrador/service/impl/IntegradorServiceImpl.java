package com.luxitec.movego.integrador.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.luxitec.movego.api.UsuarioAPI;
import com.luxitec.movego.api.UsuarioBean;
import com.luxitec.movego.integrador.bean.Localizacion;
import com.luxitec.movego.integrador.bean.Usuario;
import com.luxitec.movego.integrador.controller.MovegoResult;
import com.luxitec.movego.integrador.service.IntegradorService;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.excepciones.MoveGoException;

@Service("IntegradorService")
public class IntegradorServiceImpl  implements IntegradorService{

	private static List<Usuario> listaUsuarioOnline = new ArrayList<>();
	
	@Override
	public MovegoResult registrarLocalizacion(Usuario usuario, Localizacion localizacion) {
		MovegoResult rt = new MovegoResult();
//		if(!usuarioOnline(usuario)){
//			rt.setError(MovegoResult.USUARIO_NO_ONLINE);
//			return rt;
//		}
		rt.setContent(MovegoResult.LOCALIZACION_REGISTRADA);
		usuario.setLocalizacion(localizacion);
		registrarLocalizacion(usuario);
		return rt;
	}

	private void registrarLocalizacion(Usuario usuario) {
		System.out.println("impletar rest");
	}

	@Override
	public Usuario login(Usuario u) {
		
		try {
			UsuarioBean usuario =	UsuarioAPI.iniciarSession(u.getLogin(), u.getPass());
			if(SimpleValidador.isNull(usuario)){
				System.out.println("usuario no encontrado");
				return null;
			}
			System.out.println("usuario encontrado");
			u.setId(String.valueOf(usuario.getId()));
			u.setIdDispositivo(usuario.getIdDispositivo());
			listaUsuarioOnline.add(u);	
			u.setPass("");
		} catch (IOException | MoveGoException e) {
			e.printStackTrace();
		}
		return u;
	}

	private boolean usuarioOnline(Usuario usuario) {
		if(listaUsuarioOnline.isEmpty()){
			return false;
		}
		for (Usuario usuarioBean : listaUsuarioOnline) {
			if(usuarioBean.getId().equals(usuario.getId())){
				return true;
			}
		}
		
		
		return false;
	}
	
}
