package com.luxitec.movego.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;

import com.luxitec.movego.util.Util;

public class LocalizazcionAPI {

	private static final String URL_CONTEXT = "http://" + PropertiesInstant.getValue("host") + ":" + PropertiesInstant.getValue("puerto") + "/" + PropertiesInstant.getValue("contexto");
	private static final String URL_CONTEXT_RADIO = URL_CONTEXT+"radio/";
	private static final String URL_CONTEXT_ESTIMARENTREPUNTOS = URL_CONTEXT+"estimarEntrePuntos/";
	private static final String URL_CONTEXT_ULTIMAUBICACION = URL_CONTEXT+"ultimaUbicacion/";
	private static final String URL_CONTEXT_CONDUCTORES = URL_CONTEXT+"conductores/";
	private static final String URL_CONTEXT_USUARIOS = URL_CONTEXT+"usuarios/";
	
	public static LocalizacionBean registrarLocalizacion(LocalizacionBean localizacionBean) throws ClientProtocolException, IOException {
		String json = Util.getJson(localizacionBean);
		HttpResponse r = Util.post(URL_CONTEXT, json);
		String res = Util.getEntry(r);
		localizacionBean = (LocalizacionBean) Util.getObject(res, LocalizacionBean.class);
		return localizacionBean;
	}

	public static List<LocalizacionBean> getLocalizacionCercanas(int radioKm, Long[] idsUsuariosActivos, Long idusuario, String longitud, String latitud) throws ClientProtocolException, IOException {
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("idsUsuariosActivos", "\"" + Util.convert(idsUsuariosActivos) + "\"");
		params.put("idusuario", String.valueOf(idusuario));
		params.put("latitud", longitud);
		params.put("longitud", latitud);
		HttpResponse r = Util.get(URL_CONTEXT_RADIO + radioKm, params);
		String res = Util.getEntry(r);
		List l = (List) Util.getObject(res, ArrayList.class);
		return l;
	}

	public static Map<String, Object> estimarEntrePuntos(Long origenidusuario, String origenlongitud, String origenlatitud, Long destinoidusuario, String destinolongitud, String destinolatitud) throws ClientProtocolException, IOException {
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("origenidusuario", String.valueOf(origenidusuario));
		params.put("origenlongitud", origenlongitud);
		params.put("origenlatitud", origenlatitud);		
		params.put("destinoidusuario", String.valueOf(destinoidusuario));		
		params.put("destinolongitud", destinolongitud);
		params.put("destinolatitud", destinolatitud);
		HttpResponse r = Util.get(URL_CONTEXT_ESTIMARENTREPUNTOS, params);
		String res = Util.getEntry(r);
		Map<String, Object> o = Util.stringToMap(res);
		return o;
	}

	public static LocalizacionBean getUltimaUbicacion(Long idUsuario) throws ClientProtocolException, IOException {		
		HttpResponse r = Util.get(URL_CONTEXT_ULTIMAUBICACION+idUsuario, null);
		String res = Util.getEntry(r);
		LocalizacionBean localizacionBean = (LocalizacionBean) Util.getObject(res, LocalizacionBean.class);
		return localizacionBean;
	}

	public static List<LocalizacionBean> getListaConductores(Long[] idsConductoresActivos) throws ClientProtocolException, IOException {
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("idsConductoresActivos", "\"" + Util.convert(idsConductoresActivos) + "\"");
		HttpResponse r = Util.get(URL_CONTEXT_CONDUCTORES, params);
		String res = Util.getEntry(r);
		List l = (List) Util.getObject(res, ArrayList.class);
		return l;
	}

	public static List<LocalizacionBean> getListaUsuarios(Long[] idsUsariosActivos) throws ClientProtocolException, IOException {
		Map<String, String> params = new LinkedHashMap<String, String>();
		params.put("idsUsariosActivos", "\"" + Util.convert(idsUsariosActivos) + "\"");
		HttpResponse r = Util.get(URL_CONTEXT_USUARIOS, params);
		String res = Util.getEntry(r);
		List l = (List) Util.getObject(res, ArrayList.class);
		return l;
	}
//
//	public static void main(String[] args) {
//
//		try {
//			 LocalizacionBean localizacion = new LocalizacionBean();
//			 localizacion.setActivo(true);
//			 localizacion.setDireccionActual("av. guiberty 135");
//			 localizacion.setLatitud("-12.354645");
//			 localizacion.setLongitud("-77.34534534");
//			 localizacion.setIdUsuario(2);
//			 registrarLocalizacion(localizacion);
//
//			List<LocalizacionBean> l = getLocalizacionCercanas(5, new Long[] { 3L, 2L }, 1L, "-12.434353", "-77.2343245");
//			System.out.println(l);
//			Map<String, Object> o  = estimarEntrePuntos(2L, "-12.434353", "-77.2343245", 3L, "-12.23455", "-77.3443245");
//
//			for (Map.Entry<String, Object> entry : o.entrySet()) {
//				System.out.println(entry.getKey());
//				System.out.println(entry.getValue());
//			}
//			
//			System.out.println(getUltimaUbicacion(2l));
//			System.out.println(getListaConductores(new Long[] { 3L, 2L }));
//			System.out.println(getListaUsuarios(new Long[] { 3L, 2L }));
//			
//		} catch (ClientProtocolException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//
//	}

}
