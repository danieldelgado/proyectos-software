package com.luxitec.movego.domain;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.luxitec.movego.util.entidades.EntityDAO;

@Entity
@Table(name = "LOCALIZACION_GEO")
public class Localizacion extends EntityDAO {
	public static final Boolean TRANSCURSO_TRAYECTORIA = true; // los puntos del trasnporte
	public static final Boolean TRANSCURSO_RUTA = false; // del punto A al punto B

	private String latitud;
	private String longitud;
	private String direccionActual;
	private boolean transcurso;
	private long   idUsuario;	

	private Usuario usuario;
	
	public String getLatitud() {
		return latitud;
	}
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}
	public String getLongitud() {
		return longitud;
	}
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}
	public String getDireccionActual() {
		return direccionActual;
	}
	public void setDireccionActual(String direccionActual) {
		this.direccionActual = direccionActual;
	}
	public long getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(long idUsuario) {
		this.idUsuario = idUsuario;
	}
	
	@ManyToOne
	@JoinColumn(name = "usuario")
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public boolean isTranscurso() {
		return transcurso;
	}
	public void setTranscurso(boolean transcurso) {
		this.transcurso = transcurso;
	}
	
	
	
	
}
