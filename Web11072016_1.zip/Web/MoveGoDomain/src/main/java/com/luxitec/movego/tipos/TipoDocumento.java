package com.luxitec.movego.tipos;

public enum TipoDocumento {
	DNI("DNI"), PASAPORTE("PASAPORTE");

	private String tipoDocumento;

	TipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

}
