package com.luxitec.movego.bean;

import java.util.List;

import com.luxitec.movego.domain.Localizacion;
import com.luxitec.movego.util.entidades.EntityBean;

public class RutaBean extends EntityBean{


	private Long id;

	private Long idUsuarioSolicitante;	
	private Long idLocalizacionSolicitante;
	
	//-- no pertenece al jpa --
	private UsuarioBean usuarioSolicitante;
	private LocalizacionBean localizacionSolicitante;	
	private List<LocalizacionBean> listaLocalizacionSolicitante;
	//-------------------------
	
	private Long idUsuarioConductor;	
	private Long idLocalizacionConductor;

	//-- no pertenece al jpa --
	private UsuarioBean usuarioConductor;
	private LocalizacionBean localizacionConductor;
	private List<LocalizacionBean> listaLocalizacionConductor;
	//-------------------------
	
	private String direccionConductor;

	private String direccion;
	private String referencia;
	private long idLocalizacionDestino;
	
	//-- no pertenece al jpa --
	private Localizacion localizacionDestino;
	//-------------------------

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdUsuarioSolicitante() {
		return idUsuarioSolicitante;
	}

	public void setIdUsuarioSolicitante(Long idUsuarioSolicitante) {
		this.idUsuarioSolicitante = idUsuarioSolicitante;
	}

	public Long getIdLocalizacionSolicitante() {
		return idLocalizacionSolicitante;
	}

	public void setIdLocalizacionSolicitante(Long idLocalizacionSolicitante) {
		this.idLocalizacionSolicitante = idLocalizacionSolicitante;
	}

	public UsuarioBean getUsuarioSolicitante() {
		return usuarioSolicitante;
	}

	public void setUsuarioSolicitante(UsuarioBean usuarioSolicitante) {
		this.usuarioSolicitante = usuarioSolicitante;
	}

	public LocalizacionBean getLocalizacionSolicitante() {
		return localizacionSolicitante;
	}

	public void setLocalizacionSolicitante(LocalizacionBean localizacionSolicitante) {
		this.localizacionSolicitante = localizacionSolicitante;
	}

	public List<LocalizacionBean> getListaLocalizacionSolicitante() {
		return listaLocalizacionSolicitante;
	}

	public void setListaLocalizacionSolicitante(List<LocalizacionBean> listaLocalizacionSolicitante) {
		this.listaLocalizacionSolicitante = listaLocalizacionSolicitante;
	}

	public Long getIdUsuarioConductor() {
		return idUsuarioConductor;
	}

	public void setIdUsuarioConductor(Long idUsuarioConductor) {
		this.idUsuarioConductor = idUsuarioConductor;
	}

	public Long getIdLocalizacionConductor() {
		return idLocalizacionConductor;
	}

	public void setIdLocalizacionConductor(Long idLocalizacionConductor) {
		this.idLocalizacionConductor = idLocalizacionConductor;
	}

	public UsuarioBean getUsuarioConductor() {
		return usuarioConductor;
	}

	public void setUsuarioConductor(UsuarioBean usuarioConductor) {
		this.usuarioConductor = usuarioConductor;
	}

	public LocalizacionBean getLocalizacionConductor() {
		return localizacionConductor;
	}

	public void setLocalizacionConductor(LocalizacionBean localizacionConductor) {
		this.localizacionConductor = localizacionConductor;
	}

	public List<LocalizacionBean> getListaLocalizacionConductor() {
		return listaLocalizacionConductor;
	}

	public void setListaLocalizacionConductor(List<LocalizacionBean> listaLocalizacionConductor) {
		this.listaLocalizacionConductor = listaLocalizacionConductor;
	}

	public String getDireccionConductor() {
		return direccionConductor;
	}

	public void setDireccionConductor(String direccionConductor) {
		this.direccionConductor = direccionConductor;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public long getIdLocalizacionDestino() {
		return idLocalizacionDestino;
	}

	public void setIdLocalizacionDestino(long idLocalizacionDestino) {
		this.idLocalizacionDestino = idLocalizacionDestino;
	}

	public Localizacion getLocalizacionDestino() {
		return localizacionDestino;
	}

	public void setLocalizacionDestino(Localizacion localizacionDestino) {
		this.localizacionDestino = localizacionDestino;
	}

	
	
}
