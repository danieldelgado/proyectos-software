package com.luxitec.movego.service;

import java.util.List;

import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.tipos.TipoUsuario;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;
import com.luxitec.movego.util.service.IService;

public interface UsuarioService extends IService<UsuarioBean> {

	UsuarioBean getUsuarioForEmail(String email) throws MoveGoServiceException;
	List<UsuarioBean> getUsuarios(UsuarioBean usuario) throws MoveGoServiceException;
	long[] listaUsariosTipo(TipoUsuario tipoUsuario) throws MoveGoServiceException;
	
}
