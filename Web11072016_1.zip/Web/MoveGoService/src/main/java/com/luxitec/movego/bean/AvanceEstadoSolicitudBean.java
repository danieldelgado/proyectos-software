package com.luxitec.movego.bean;

import com.luxitec.movego.tipos.EstadoTransporte;
import com.luxitec.movego.util.entidades.EntityBean;


public class AvanceEstadoSolicitudBean  extends EntityBean {

	private SolicitudTransporteBean solicitudTransporteBean;
	private EstadoTransporte estadoTransporte;
	
	public SolicitudTransporteBean getSolicitudTransporteBean() {
		return solicitudTransporteBean;
	}
	public void setSolicitudTransporteBean(SolicitudTransporteBean solicitudTransporteBean) {
		this.solicitudTransporteBean = solicitudTransporteBean;
	}
	public EstadoTransporte getEstadoTransporte() {
		return estadoTransporte;
	}
	public void setEstadoTransporte(EstadoTransporte estadoTransporte) {
		this.estadoTransporte = estadoTransporte;
	}
	
	
	
}
