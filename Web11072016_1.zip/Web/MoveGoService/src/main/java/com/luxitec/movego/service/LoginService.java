package com.luxitec.movego.service;

import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;
import com.luxitec.movego.util.service.IService;

public interface LoginService extends IService<UsuarioBean> {

	UsuarioBean getUsuarioForEmail(String email)  throws MoveGoServiceException;

	UsuarioBean getIniciarSession(String email, String password)  throws MoveGoServiceException;

	UsuarioBean registrarse(UsuarioBean usuario)  throws MoveGoServiceException;

	
}
