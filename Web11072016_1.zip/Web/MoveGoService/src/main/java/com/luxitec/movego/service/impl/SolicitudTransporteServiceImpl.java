package com.luxitec.movego.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxitec.movego.bean.RutaBean;
import com.luxitec.movego.bean.SolicitudTransporteBean;
import com.luxitec.movego.dao.SolicitudTransporteDAO;
import com.luxitec.movego.domain.SolicitudTransporte;
import com.luxitec.movego.service.RutaService;
import com.luxitec.movego.service.SolicitudTransporteService;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.Trasnfer;
import com.luxitec.movego.util.constantes.ConstantesUtil;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("SolicitudTransporteService")
public class SolicitudTransporteServiceImpl implements SolicitudTransporteService {

	private static final Logger LOG = LoggerFactory.getLogger(SolicitudTransporteServiceImpl.class);

	@Autowired
	private SolicitudTransporteDAO solicitudTransporteDAO;

	@Autowired
	private RutaService rutaService;

	@Transactional
	@Override
	public void registrarSolicitudTransporte(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		guardar(solicitudTransporteBean);
		registrarRuta(solicitudTransporteBean);
	}

	private void registrarRuta(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		RutaBean r = solicitudTransporteBean.getRuta();
		rutaService.guardar(r);
		solicitudTransporteBean.setRuta(r);
	}

	@Transactional
	@Override
	public void guardar(SolicitudTransporteBean o) throws MoveGoServiceException {
		LOG.debug("guardar");
		try {
			o.setFechaRegistro(new Date());
			o.setActivo(true);
			SolicitudTransporte t = new SolicitudTransporte();
			Trasnfer.copyFields(o, t);
			solicitudTransporteDAO.guardar(t);
			t.setIdUsuarioRegistra(o.getRuta().getUsuarioSolicitante().getId());
			t.setIdUsuarioModifica(o.getRuta().getUsuarioSolicitante().getId());
			t.setFechaRegistro(new Date());
			t.setFechaActualizacion(new Date());
			solicitudTransporteDAO.guardar(t);
			Trasnfer.copyFields(t, o);
		} catch (MoveGoDAOException e) {
			LOG.error("Error al guardar:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(ConstantesUtil.Errors.ERROR_ENTIDAD_GUARDAR);
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}

	}

	@Override
	public SolicitudTransporteBean get(Long id) throws MoveGoServiceException {
		SolicitudTransporte s;
		try {
			s = solicitudTransporteDAO.get(id);
			if(SimpleValidador.isNotNull(s)){
				SolicitudTransporteBean t = new SolicitudTransporteBean();
				Trasnfer.copyFields(s, t);
				return t;
			}			
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		} catch (MoveGoException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void enviarAlertaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		LOG.info("falta ver como se enviara la alerta por gcm");

	}

	@Override
	public void cancelarAlertaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		LOG.info("falta ver como se cancelar la alerta por gcm");

	}

	@Override
	public void aceptaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		LOG.info("falta ver como se aceptar la alerta por gcm");

	}

	@Override
	public void iniciarTrasnporte(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		LOG.info("falta ver como se iniciar la alerta por gcm");

	}

	@Override
	public void finalizacionTrasnporte(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException {
		LOG.info("falta ver como se finalizar la alerta por gcm");

	}

	@Override
	public SolicitudTransporteBean getUltimaSolicitudTransporteBeanForUsuarioSolicitante(Long idUsuarioSolicitante) throws MoveGoServiceException {
		
		try {
			SolicitudTransporte s = solicitudTransporteDAO.getUltimaSolicitudTransporteBeanForUsuarioSolicitante(idUsuarioSolicitante);
		
		
		
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		}
		
		
		
		return null;
	}

	@Override
	public void habilitar(SolicitudTransporteBean obj, boolean activo) throws MoveGoServiceException {
		try {
			SolicitudTransporte a = solicitudTransporteDAO.get(obj.getId());
			solicitudTransporteDAO.habilitar(a, activo);
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<SolicitudTransporteBean> todo() throws MoveGoServiceException {
		List<SolicitudTransporte> lista = null;
		try {
			lista = solicitudTransporteDAO.todo();
		} catch (MoveGoDAOException e1) {
			e1.printStackTrace();
		}
		List<SolicitudTransporteBean> lretunr = new ArrayList<>();
		SolicitudTransporteBean bre = null;
		try {
			for (SolicitudTransporte s : lista) {
				bre = new SolicitudTransporteBean();
				Trasnfer.copyFields(s, bre);
				lretunr.add(bre);
			}
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
		return lretunr;
	}

	@Override
	public List<SolicitudTransporteBean> getSolicitudesTransportePorUsuarioSolicitante(Long idUsuarioSolicitante) throws MoveGoServiceException {
		List<SolicitudTransporte> lista = null;
		try {
			lista = solicitudTransporteDAO.getSolicitudesTransportePorUsuarioSolicitante(idUsuarioSolicitante);
		} catch (MoveGoDAOException e1) {
			e1.printStackTrace();
		}
		List<SolicitudTransporteBean> lretunr = new ArrayList<>();
		SolicitudTransporteBean bre = null;
		try {
			for (SolicitudTransporte s : lista) {
				bre = new SolicitudTransporteBean();
				Trasnfer.copyFields(s, bre);
				lretunr.add(bre);
			}
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
		return lretunr;
	}

	
	
	

	
}
