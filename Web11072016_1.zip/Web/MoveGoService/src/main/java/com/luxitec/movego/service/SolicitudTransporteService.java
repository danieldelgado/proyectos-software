package com.luxitec.movego.service;

import java.util.List;

import com.luxitec.movego.bean.SolicitudTransporteBean;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;
import com.luxitec.movego.util.service.IService;

public interface SolicitudTransporteService extends IService<SolicitudTransporteBean> {

	void enviarAlertaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException;
	
	void cancelarAlertaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException;
	
	void aceptaSolicitud(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException;
	
	void registrarSolicitudTransporte( SolicitudTransporteBean solicitudTransporteBean ) throws MoveGoServiceException;
	
	void iniciarTrasnporte(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException;
	
	void finalizacionTrasnporte(SolicitudTransporteBean solicitudTransporteBean) throws MoveGoServiceException;
	
	SolicitudTransporteBean getUltimaSolicitudTransporteBeanForUsuarioSolicitante( Long idUsuarioSolicitante) throws MoveGoServiceException;
	
	List<SolicitudTransporteBean> getSolicitudesTransportePorUsuarioSolicitante( Long idUsuarioSolicitante) throws MoveGoServiceException;
	
}
