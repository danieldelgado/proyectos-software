package com.luxitec.movego.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.ImagenBean;
import com.luxitec.movego.dao.ImagenDAO;
import com.luxitec.movego.domain.Imagen;
import com.luxitec.movego.service.ImagenService;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.Trasnfer;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("ImagenService")
public class ImagenServiceImpl implements ImagenService {

	private static final Logger LOG = LoggerFactory.getLogger(ImagenServiceImpl.class);

	@Autowired
	private ImagenDAO imagenDAO;
	
	@Override
	public void guardar(ImagenBean o) throws MoveGoServiceException {
		try {
			Imagen i = imagenDAO.get(o.getId());			
			if(SimpleValidador.isNull(i)){				
				Trasnfer.copyFields(o, i);
				i.setActivo(true);
				i.setFechaRegistro(new Date());
				i.setFechaActualizacion(new Date());
				imagenDAO.guardar(i);				
			}			
			
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		} catch (MoveGoException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public ImagenBean get(Long id) throws MoveGoServiceException {
		try {
			Imagen i = imagenDAO.get(id);		
			if(SimpleValidador.isNotNull(i)){	
				ImagenBean r = new ImagenBean();
				Trasnfer.copyFields(i, r);
				return r;
			}
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		} catch (MoveGoException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void habilitar(ImagenBean obj, boolean activo) throws MoveGoServiceException {
		try {
			Imagen a = imagenDAO.get(obj.getId());
			imagenDAO.habilitar(a, activo);
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		}		
	}

	@Override
	public List<ImagenBean> todo() throws MoveGoServiceException {
		List<Imagen> lista = null;
		try {
			lista = imagenDAO.todo();
		} catch (MoveGoDAOException e1) {
			e1.printStackTrace();
		}
		List<ImagenBean> lretunr = new ArrayList<>();
		ImagenBean bre = null;
		try {
			for (Imagen is : lista) {
				bre = new ImagenBean();
				Trasnfer.copyFields(is, bre);
				lretunr.add(bre);
			}
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}

		return lretunr;
	}
	

}
