package com.luxitec.movego.service;

import java.util.List;

import com.luxitec.movego.bean.RutaBean;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;
import com.luxitec.movego.util.service.IService;

public interface RutaService extends IService<RutaBean>{

	RutaBean getUltimaRuta( Long idUsuarioSolicitante ) throws MoveGoServiceException;
	List<RutaBean> getRutasUsuario( Long idUsuarioSolicitante ) throws MoveGoServiceException;
	void anularRuta(RutaBean rutaBean) throws MoveGoServiceException;
}
