package com.luxitec.movego.bean;

import java.util.Date;

import com.luxitec.movego.tipos.EstadoTransporte;
import com.luxitec.movego.util.entidades.EntityBean;


public class SolicitudTransporteBean extends EntityBean{

	private Long id;

	private RutaBean ruta;
	
	private String tiempoEstimado;
	private String tiempoFinalizado;
	
	private String costoEstimado;
	private String costoFinal;
	
	private boolean trayectoriaTerminada;
	
	private EstadoTransporte estadoTransporte;
	private boolean activo;
	
	private Date fechaRegistro;
	private Long idUsuarioRegistra;
	private Date fechaActualizacion;
	private Long idUsuarioModifica;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public RutaBean getRuta() {
		return ruta;
	}
	public void setRuta(RutaBean ruta) {
		this.ruta = ruta;
	}
	public String getTiempoEstimado() {
		return tiempoEstimado;
	}
	public void setTiempoEstimado(String tiempoEstimado) {
		this.tiempoEstimado = tiempoEstimado;
	}
	public String getTiempoFinalizado() {
		return tiempoFinalizado;
	}
	public void setTiempoFinalizado(String tiempoFinalizado) {
		this.tiempoFinalizado = tiempoFinalizado;
	}
	public String getCostoEstimado() {
		return costoEstimado;
	}
	public void setCostoEstimado(String costoEstimado) {
		this.costoEstimado = costoEstimado;
	}
	public String getCostoFinal() {
		return costoFinal;
	}
	public void setCostoFinal(String costoFinal) {
		this.costoFinal = costoFinal;
	}
	public boolean isTrayectoriaTerminada() {
		return trayectoriaTerminada;
	}
	public void setTrayectoriaTerminada(boolean trayectoriaTerminada) {
		this.trayectoriaTerminada = trayectoriaTerminada;
	}
	public EstadoTransporte getEstadoTransporte() {
		return estadoTransporte;
	}
	public void setEstadoTransporte(EstadoTransporte estadoTransporte) {
		this.estadoTransporte = estadoTransporte;
	}
	public boolean isActivo() {
		return activo;
	}
	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public Long getIdUsuarioRegistra() {
		return idUsuarioRegistra;
	}
	public void setIdUsuarioRegistra(Long idUsuarioRegistra) {
		this.idUsuarioRegistra = idUsuarioRegistra;
	}
	public Date getFechaActualizacion() {
		return fechaActualizacion;
	}
	public void setFechaActualizacion(Date fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}
	public Long getIdUsuarioModifica() {
		return idUsuarioModifica;
	}
	public void setIdUsuarioModifica(Long idUsuarioModifica) {
		this.idUsuarioModifica = idUsuarioModifica;
	}
	
	

}
