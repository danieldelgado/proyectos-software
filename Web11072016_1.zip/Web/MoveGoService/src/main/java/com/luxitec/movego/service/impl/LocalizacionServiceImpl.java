package com.luxitec.movego.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxitec.movego.bean.LocalizacionBean;
import com.luxitec.movego.dao.LocalizacionDAO;
import com.luxitec.movego.domain.Localizacion;
import com.luxitec.movego.service.LocalizacionService;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.Trasnfer;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("LocalizacionService")
public class LocalizacionServiceImpl implements LocalizacionService {

	private static final Logger LOG = LoggerFactory.getLogger(LocalizacionServiceImpl.class);

	@Autowired
	private LocalizacionDAO localizacionDAO;

	@Transactional
	@Override
	public void guardar(LocalizacionBean o) throws MoveGoServiceException {
		Localizacion l = null;
		try {
			if (SimpleValidador.isNotNull(o)) {
				l = new Localizacion();
				Trasnfer.copyFields(o, l);
				l.setActivo(true);
				l.setFechaRegistro(new Date());
				l.setIdUsuarioRegistra(o.getIdUsuario());
				l.setFechaActualizacion(new Date());
				l.setIdUsuarioModifica(o.getIdUsuario());
				localizacionDAO.guardar(l);
				Trasnfer.copyFields(l, o);
			}

		} catch (MoveGoDAOException e) {
			throw new MoveGoServiceException(3, "Error al guardar");
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}

	}

	@Override
	public LocalizacionBean get(Long id) throws MoveGoServiceException {
		LocalizacionBean to = null;
		try {
			Localizacion a = localizacionDAO.get(id);
			if (a != null) {
				to = new LocalizacionBean();
				Trasnfer.copyFields(a, to);
			}
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		} catch (MoveGoException e) {
			e.printStackTrace();
		}
		return to;
	}

	@Override
	public void habilitar(LocalizacionBean obj, boolean activo) throws MoveGoServiceException {
		try {
			Localizacion a = localizacionDAO.get(obj.getId());
			localizacionDAO.habilitar(a, activo);
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<LocalizacionBean> todo() throws MoveGoServiceException {
		List<Localizacion> lista = null;
		try {
			lista = localizacionDAO.todo();
		} catch (MoveGoDAOException e1) {
			e1.printStackTrace();
		}
		List<LocalizacionBean> lretunr = new ArrayList<>();
		LocalizacionBean bre = null;
		try {
			for (Localizacion lo : lista) {
				bre = new LocalizacionBean();
				Trasnfer.copyFields(lo, bre);
				lretunr.add(bre);
			}
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}

		return lretunr;
	}

	@Override
	public List<LocalizacionBean> getLocalizacionCercanas(LocalizacionBean origen, int radioKm, Long[] idsUsuariosActivos) throws MoveGoServiceException {
		LOG.info("getLocalizacionCercanas");
		List<LocalizacionBean> lretunr = new ArrayList<>();
		try {

			Localizacion o = new Localizacion();
			Trasnfer.copyFields(origen, o);
			List<Localizacion> l = localizacionDAO.getLocalizacionCercanas(o, radioKm, idsUsuariosActivos);

			LocalizacionBean bre = null;

			for (Localizacion lo : l) {
				bre = new LocalizacionBean();
				Trasnfer.copyFields(lo, bre);
				lretunr.add(bre);
			}

		} catch (MoveGoException e) {
			e.printStackTrace();
		}

		return lretunr;
	}

	@Override
	public LocalizacionBean getUltimaUbicacion(Long idUsuario) throws MoveGoServiceException {
		Localizacion l = localizacionDAO.getUltimaUbicacion(idUsuario);
		LocalizacionBean rl = get(l.getId());
		return rl;
	}

	@Override
	public List<LocalizacionBean> getListaConductores(Long[] idsConductoresActivos) throws MoveGoServiceException {
		LOG.info("getListaConductores");
		try {

			List<Localizacion> l = localizacionDAO.getListaConductores(idsConductoresActivos);
			List<LocalizacionBean> lretunr = new ArrayList<>();
			LocalizacionBean bre = null;

			for (Localizacion lo : l) {
				bre = new LocalizacionBean();
				Trasnfer.copyFields(lo, bre);
				lretunr.add(bre);
			}
			return lretunr;

		} catch (MoveGoException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<LocalizacionBean> getListaUsuarios(Long[] idsUusariosActivos) throws MoveGoServiceException {
		LOG.info("getListaUsuarios");
		try {

			List<Localizacion> l = localizacionDAO.getListaUsuarios(idsUusariosActivos);
			List<LocalizacionBean> lretunr = new ArrayList<>();
			LocalizacionBean bre = null;

			for (Localizacion lo : l) {
				bre = new LocalizacionBean();
				Trasnfer.copyFields(lo, bre);
				lretunr.add(bre);
			}
			return lretunr;
			
		} catch (MoveGoException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public Map<String, Object> estimarEntrePuntos(LocalizacionBean origen, LocalizacionBean destino) throws MoveGoServiceException {
		LOG.info("estimarEntrePuntos");
		Map<String, Object> o = new HashMap<>();
		o.put(LocalizacionService.DISTANCIA_KEY, "123.13");
		o.put(LocalizacionService.TIEMPO_KEY, new Long(54698668687587L));
		o.put(LocalizacionService.PRECIO_KEY, "12.00");

		return o;
	}

}
