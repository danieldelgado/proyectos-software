package com.luxitec.movego.service;

import java.util.List;

import com.luxitec.movego.bean.VehiculoBean;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;
import com.luxitec.movego.util.service.IService;

public interface VehiculoService extends IService<VehiculoBean> {

	VehiculoBean getVehiculoActual(long idUsuario) throws MoveGoServiceException  ; 
	List<VehiculoBean> getListaVehiculos(long idUsuario) throws MoveGoServiceException  ;
	VehiculoBean getVehiculo(Long idVehiculo) throws MoveGoServiceException  ;
	
}
