package com.luxitec.movego.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.dao.UsuarioDAO;
import com.luxitec.movego.domain.Usuario;
import com.luxitec.movego.service.UsuarioService;
import com.luxitec.movego.tipos.TipoUsuario;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.Trasnfer;
import com.luxitec.movego.util.constantes.ConstantesUtil;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("UsuarioService")
public class UsuarioServiceImpl implements UsuarioService {

	private static final Logger LOG = LoggerFactory.getLogger(UsuarioServiceImpl.class);

	@Autowired
	private UsuarioDAO usuarioDAO;

	@Override
	public UsuarioBean getUsuarioForEmail(String email) throws MoveGoServiceException {
		LOG.debug("getUsuarioForEmail");
		UsuarioBean a = null;
		Usuario u = null;
		try {
			if (!SimpleValidador.validateEmail(email)) {
				throw new MoveGoServiceException(ConstantesUtil.Errors.ERROR_ENTIDAD_VALIDAR, "Formato del Email es incorrecto");
			}
			u = usuarioDAO.getUsuarioForEmail(email);
			if (u != null) {
				a = new UsuarioBean();
				Trasnfer.copyFields(u, a);
			}
		} catch (MoveGoDAOException e) {
			LOG.error("Error al guardar:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(ConstantesUtil.Errors.ERROR_ENTIDAD_NO_ENCONTRADA);
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
		return a;
	}

	@Override
	public void guardar(UsuarioBean a) throws MoveGoServiceException {
		LOG.debug("guardar");
		try {
			a.setFechaRegistro(new Date());
			a.setActivo(true);
			Usuario u = new Usuario();
			Trasnfer.copyFields(a, u);
			usuarioDAO.guardar(u);
			u.setIdUsuarioRegistra(u.getId());
			u.setFechaActualizacion(new Date());
			u.setIdUsuarioModifica(u.getId());
			usuarioDAO.guardar(u);
			Trasnfer.copyFields(u, a);
		} catch (MoveGoDAOException e) {
			LOG.error("Error al guardar:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(ConstantesUtil.Errors.ERROR_ENTIDAD_GUARDAR);
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
	}

	@Override
	public UsuarioBean get(Long id) throws MoveGoServiceException {
		LOG.debug("getUsuario");
		UsuarioBean ub = null;
		try {
			Usuario u = usuarioDAO.get(id);
			if (u != null) {
				ub = new UsuarioBean();
				Trasnfer.copyFields(u, ub);
			}
		} catch (MoveGoDAOException e) {
			LOG.error("Error al guardar:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(ConstantesUtil.Errors.ERROR_ENTIDAD_GUARDAR);
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
		return ub;
	}

	@Override
	public void habilitar(UsuarioBean obj, boolean activo) throws MoveGoServiceException {
		Usuario u;
		try {
			u = usuarioDAO.get(obj.getId());
			if (u != null) {
				usuarioDAO.habilitar(u, activo);
			}
		} catch (MoveGoDAOException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
	}

	@Override
	public List<UsuarioBean> todo() throws MoveGoServiceException {
		List<Usuario> lst = null;
		try {
			lst = usuarioDAO.todo();
		} catch (MoveGoDAOException e1) {
			e1.printStackTrace();
		}
		if (lst != null && !lst.isEmpty()) {
			UsuarioBean ub = null;
			List<UsuarioBean> lstUsuarioBean = new ArrayList<>();
			try {
				for (Usuario usuario : lst) {
					ub = new UsuarioBean();
					Trasnfer.copyFields(usuario, ub);
					lstUsuarioBean.add(ub);
				}
			} catch (MoveGoException e) {
				e.printStackTrace();
			}
			return lstUsuarioBean;
		}
		return null;
	}

	@Override
	public List<UsuarioBean> getUsuarios(UsuarioBean usuario) throws MoveGoServiceException {
		List<UsuarioBean> lstUsuarioBean = null;
		try {
			validateUsuario(usuario);
			Usuario u = new Usuario();
			Trasnfer.copyFields(usuario, u);
			List<Usuario> listadoUsuarios = usuarioDAO.getUsuarios(u);
			UsuarioBean ub = null;
			lstUsuarioBean = new ArrayList<>();
			for (Usuario usua : listadoUsuarios) {
				ub = new UsuarioBean();
				Trasnfer.copyFields(usua, ub);
				lstUsuarioBean.add(ub);
			}
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
		return lstUsuarioBean;
	}

	private void validateUsuario(UsuarioBean usuario) throws MoveGoServiceException {
		int errores = 0;
		if (SimpleValidador.validateEmail(usuario.getEmail())) {
			errores++;
		}
		if (errores > 0) {
			throw new MoveGoServiceException(ConstantesUtil.Errors.MENSAJE_VALIDADCION_INCORRECTA);
		}
	}

	@Override
	public long[] listaUsariosTipo(TipoUsuario tipoUsuario) throws MoveGoServiceException {
		List<Usuario> lus = usuarioDAO.getListaUsariosTipo(tipoUsuario);
		if(lus.isEmpty()){
			return null;
		}
		long[] l = new long[lus.size()];
		for (int i = 0; i < lus.size(); i++) {
			l[0] = lus.get(i).getId();
		}
		return null;
	}

}
