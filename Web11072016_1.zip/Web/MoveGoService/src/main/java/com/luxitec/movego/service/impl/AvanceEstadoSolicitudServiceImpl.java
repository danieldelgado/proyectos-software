package com.luxitec.movego.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxitec.movego.bean.AvanceEstadoSolicitudBean;
import com.luxitec.movego.dao.AvanceEstadoSolicitudDAO;
import com.luxitec.movego.dao.SolicitudTransporteDAO;
import com.luxitec.movego.domain.AvanceEstadoSolicitud;
import com.luxitec.movego.domain.SolicitudTransporte;
import com.luxitec.movego.service.AvanceEstadoSolicitudService;
import com.luxitec.movego.tipos.EstadoTransporte;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.Trasnfer;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("AvanceEstadoSolicitudService")
public class AvanceEstadoSolicitudServiceImpl implements AvanceEstadoSolicitudService {

	private static final Logger LOG = LoggerFactory.getLogger(AvanceEstadoSolicitudServiceImpl.class);

	@Autowired
	private AvanceEstadoSolicitudDAO avanceEstadoSolicitudDAO;

	@Autowired
	private SolicitudTransporteDAO solicitudTransporteDAO;

	@Transactional
	@Override
	public void guardar(AvanceEstadoSolicitudBean o) throws MoveGoServiceException {
		AvanceEstadoSolicitud avanceEstadoSolicitud = null;
		try {
			if (SimpleValidador.isNotNull(o)) {
				avanceEstadoSolicitud = new AvanceEstadoSolicitud();
				Trasnfer.copyFields(o, avanceEstadoSolicitud);
				
				avanceEstadoSolicitud.setActivo(true);
				avanceEstadoSolicitud.setFechaRegistro(new Date());
				avanceEstadoSolicitud.setFechaActualizacion(new Date());
				
				avanceEstadoSolicitudDAO.guardar(avanceEstadoSolicitud);
			}

		} catch (MoveGoDAOException e) {
			throw new MoveGoServiceException(3, "Error al guardar el avance de estado");
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
	}

	@Override
	public AvanceEstadoSolicitudBean get(Long id) throws MoveGoServiceException {
		AvanceEstadoSolicitudBean to = null;
		try {
			AvanceEstadoSolicitud a = avanceEstadoSolicitudDAO.get(id);
			if (a != null) {
				to = new AvanceEstadoSolicitudBean();
				Trasnfer.copyFields(a, to);
			}
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		} catch (MoveGoException e) {
			e.printStackTrace();
		}
		return to;
	}

	@Override
	public void registrarAvanceEstado(Long idSolicitud, EstadoTransporte estado, long usuario) throws MoveGoServiceException {

		try {
			SolicitudTransporte s = solicitudTransporteDAO.get(idSolicitud);
			if (SimpleValidador.isNotNull(s)) {
				if (!s.getEstadoTransporte().getEstado().equalsIgnoreCase(estado.getEstado())) {
					AvanceEstadoSolicitud a = new AvanceEstadoSolicitud();
					a.setSolicitud(s);
					a.setEstadoTransporte(estado);
					a.setActivo(true);
					a.setFechaRegistro(new Date());
					a.setFechaActualizacion(new Date());
					a.setIdUsuarioModifica(usuario);
					a.setIdUsuarioRegistra(usuario);
					avanceEstadoSolicitudDAO.guardar(a);
				}
			}
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void habilitar(AvanceEstadoSolicitudBean obj, boolean activo) throws MoveGoServiceException {
		try {
			AvanceEstadoSolicitud a = avanceEstadoSolicitudDAO.get(obj.getId());
			avanceEstadoSolicitudDAO.habilitar(a, activo);
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<AvanceEstadoSolicitudBean> todo() throws MoveGoServiceException {
		List<AvanceEstadoSolicitud> lista = null;
		try {
			lista = avanceEstadoSolicitudDAO.todo();
		} catch (MoveGoDAOException e1) {
			e1.printStackTrace();
		}
		List<AvanceEstadoSolicitudBean> lretunr = new ArrayList<>();
		AvanceEstadoSolicitudBean bre = null;
		try {
			for (AvanceEstadoSolicitud avanceEstadoSolicitud : lista) {
				bre = new AvanceEstadoSolicitudBean();
				Trasnfer.copyFields(avanceEstadoSolicitud, bre);
				lretunr.add(bre);
			}
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}

		return lretunr;
	}

	@Override
	public List<AvanceEstadoSolicitudBean> getListaAvanceEstadoSolicitud(Long idSolicitud) {
		List<AvanceEstadoSolicitud> lista = avanceEstadoSolicitudDAO.getListaAvanceEstadoSolicitud(idSolicitud);
		if (!lista.isEmpty()) {
			List<AvanceEstadoSolicitudBean> lretunr = new ArrayList<>();
			AvanceEstadoSolicitudBean bre = null;
			bre = new AvanceEstadoSolicitudBean();
			try {
				for (AvanceEstadoSolicitud avanceEstadoSolicitud : lista) {
					Trasnfer.copyFields(avanceEstadoSolicitud, bre);

					lretunr.add(bre);
				}
			} catch (MoveGoException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

}
