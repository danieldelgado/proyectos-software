package com.luxitec.movego.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.luxitec.movego.bean.VehiculoBean;
import com.luxitec.movego.dao.VehiculoDAO;
import com.luxitec.movego.domain.Vehiculo;
import com.luxitec.movego.service.VehiculoService;
import com.luxitec.movego.util.SimpleValidador;
import com.luxitec.movego.util.Trasnfer;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
import com.luxitec.movego.util.excepciones.MoveGoException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@Service("VehiculoService")
public class VehiculoServiceImpl implements VehiculoService {

	private static final Logger LOG = LoggerFactory.getLogger(VehiculoServiceImpl.class);

	@Autowired
	private VehiculoDAO vehiculoDAO;
	
	@Transactional
	@Override
	public void guardar(VehiculoBean o) throws MoveGoServiceException {
		Vehiculo v = null;
		try {
			if (SimpleValidador.isNotNull(o)) {
				v = new Vehiculo();
				Trasnfer.copyFields(o, v);
				vehiculoDAO.guardar(v);
			}

		} catch (MoveGoDAOException e) {
			throw new MoveGoServiceException(3, "Error al guardar el vehiculo");
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
	}

	@Override
	public VehiculoBean get(Long id) throws MoveGoServiceException {
		VehiculoBean to = null;
		try {
			Vehiculo a = vehiculoDAO.get(id);
			if (a != null) {
				to = new VehiculoBean();
				Trasnfer.copyFields(a, to);
			}
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		} catch (MoveGoException e) {
			e.printStackTrace();
		}
		return to;
	}

	@Override
	public VehiculoBean getVehiculo(Long idVehiculo) throws MoveGoServiceException  {
		return get(idVehiculo);		
	}

	@Override
	public void habilitar(VehiculoBean obj, boolean activo) throws MoveGoServiceException {
		try {
			Vehiculo a = vehiculoDAO.get(obj.getId());
			vehiculoDAO.habilitar(a, activo);
		} catch (MoveGoDAOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<VehiculoBean> todo() throws MoveGoServiceException {
		List<Vehiculo> lista = null;
		try {
			lista = vehiculoDAO.todo();
		} catch (MoveGoDAOException e1) {
			e1.printStackTrace();
		}
		List<VehiculoBean> lretunr = new ArrayList<>();
		VehiculoBean bre = null;
		try {
			for (Vehiculo obj : lista) {
				bre = new VehiculoBean();
				Trasnfer.copyFields(obj, bre);
				lretunr.add(bre);
			}
		} catch (MoveGoException e) {
			LOG.error("Error en tranferencia de datos:" + e.getLocalizedMessage(), e);
			throw new MoveGoServiceException(e.getCodigoError());
		}
		return lretunr;
	}

	@Override
	public VehiculoBean getVehiculoActual(long idUsuario) throws MoveGoServiceException  {		
		Vehiculo v = vehiculoDAO.getVehiculoActual(idUsuario);
		VehiculoBean rv = get(v.getId());
		return rv;
	}

	@Override
	public List<VehiculoBean> getListaVehiculos(long idUsuario)  throws MoveGoServiceException  {
		List<VehiculoBean> lretunr = new ArrayList<>();
		List<Vehiculo> v = vehiculoDAO.getListaVehiculos(idUsuario);
		if(!v.isEmpty()){
			VehiculoBean rv = null;
			for (Vehiculo vehiculo : v) {
				rv = get(vehiculo.getId());
				lretunr.add(rv);			
			}			
			return lretunr;
		}
		return null;
	}

}
