package com.luxitec.movego.usuario.controller.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.service.LoginService;
import com.luxitec.movego.util.constantes.ConstantesUtil;
import com.luxitec.movego.util.excepciones.MoveGoControllerException;
import com.luxitec.movego.util.excepciones.MoveGoServiceException;

@RestController
@RequestMapping("/login")
public class LoginRestController {

	@Autowired
	private LoginService loginservice;

	/**
	 * inicio de session del usuario
	 * 
	 * @param email
	 * @param password
	 * @return
	 * @throws MoveGoControllerException
	 */
	@ResponseBody
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public UsuarioBean iniciarSession(@RequestParam(value = "email", required = true) String email, @RequestParam(value = "password", required = true) String password) throws MoveGoControllerException {
		System.out.println("iniciarSession");
		UsuarioBean u = null;
		try {
			u = loginservice.getIniciarSession(email, password);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}

		return u;
	}

	/**
	 * Metodo retorna 1 si el emial exite o 0 sino exite
	 * 
	 * @param email
	 * @return
	 * @throws MoveGoControllerException
	 */
	@RequestMapping(value = "/usuario", method = RequestMethod.GET)
	public int exiteUsuario(@RequestParam(value = "email", required = true, defaultValue = "0") String email) throws MoveGoControllerException {
		try {
			UsuarioBean u = loginservice.getUsuarioForEmail(email);
			if (null != u) {
				return ConstantesUtil.TRANSACCION_OK;
			}
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}
		return ConstantesUtil.TRANSACCION_NO_OK;
	}

	/**
	 * Permite registrar en la aplicacion
	 * 
	 * @param usuario
	 * @return
	 * @throws MoveGoControllerException
	 */
	@ResponseBody
	@RequestMapping(value = "/registrarse", method = RequestMethod.POST)
	public UsuarioBean registrarse(@RequestBody UsuarioBean usuario) throws MoveGoControllerException {

		UsuarioBean u = null;
		try {
			u = loginservice.registrarse(usuario);
		} catch (MoveGoServiceException e) {
			throw new MoveGoControllerException(e.getCodigoError(), e.getErrorMessage());
		}

		return u;
	}

}