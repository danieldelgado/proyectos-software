package com.luxitec.movego.usuario.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.luxitec.movego.bean.UsuarioBean;
import com.luxitec.movego.dao.UsuarioDAO;
import com.luxitec.movego.util.excepciones.MoveGoDAOException;
@SuppressWarnings("rawtypes") 
@Component
public class LoginValidator implements Validator {

	private static final Logger LOG = LoggerFactory.getLogger(LoginValidator.class);
	
	@Autowired
	private UsuarioDAO usuarioDAO;
	
    public boolean supports(Class aClass) {
        return String.class.equals(aClass);
    }

    public void validate(Object obj, Errors errors) {
    	String usuarioBean = (String) obj;  
         try {
			if (usuarioDAO.getUsuarioForEmail(usuarioBean) != null) {
			     errors.rejectValue("email", "NonUniq.user");
			 }
		} catch (MoveGoDAOException e) {
			LOG.error("Error en validacion:"+e.getLocalizedMessage(),e);
		}
    	
//    	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName",
//                "username.required", "Required field");
//        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPassword",
//                "userpassword.required", "Required field");
        
        
        
        
        
    }
}